package com.example.pintugame;

import java.util.ArrayList;
import java.util.Collections;

import android.os.Bundle;
import android.app.Activity;
import android.view.View.OnClickListener;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
	Button b[]=new Button[9];
	Button n;
	Button start;
	Button close;
	OnClickListener o1 = null;
	OnClickListener o2 = null;
	OnClickListener o3 = null;
	TextView show;
	int count=0;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("����ƴͼ��Ϸ");
        start=(Button) findViewById(R.id.start);
        close=(Button) findViewById(R.id.close);
        b[0]=(Button) findViewById(R.id.button1);
        b[1]=(Button) findViewById(R.id.button2);
        b[2]=(Button) findViewById(R.id.button3);
        b[3]=(Button) findViewById(R.id.button4);
        b[4]=(Button) findViewById(R.id.button5);
        b[5]=(Button) findViewById(R.id.button6);
        b[6]=(Button) findViewById(R.id.button7);
        b[7]=(Button) findViewById(R.id.button8);
        n=b[8]=(Button) findViewById(R.id.button9);
        show=(TextView) findViewById(R.id.defen);
        
        o1= new OnClickListener(){

			@Override
			public void onClick(View v) {
				ArrayList<Integer> A=new ArrayList<Integer>();
				for (int i = 1; i <= 9; i++) {
					A.add(i);
				}
				Collections.shuffle(A);
				for (int j = 0; j <= 8; j++) {
					if(A.get(j)==9){
						b[j].setText("");
						n=b[j];
						}else{
					b[j].setText(A.get(j)+"");	
					}
				}
				count=0;
				show.setText(count+"");
			}
        };
        o2=new OnClickListener(){

			@Override
			public void onClick(View v) {
				Button t = (Button) v;
				if(t==b[0]){
					if(n==b[1]||n==b[3]){
						exchange(t);
					}
				}
				else if(t==b[1]){
					if(n==b[0]||n==b[2]||n==b[4]){
						exchange(t);
					}
				}
				else if(t==b[2]){
					if(n==b[1]||n==b[5]){
						exchange(t);
					}
				}
				else if(t==b[3]){
					if(n==b[0]||n==b[4]||n==b[6]){
						exchange(t);
					}
				}
				else if(t==b[4]){
					if(n==b[1]||n==b[3]||n==b[5]||n==b[7]){
						exchange(t);
					}
				}
				else if(t==b[5]){
					if(n==b[2]||n==b[8]||n==b[4]){
						exchange(t);
					}
				}
				else if(t==b[6]){
					if(n==b[3]||n==b[7]){
						exchange(t);
					}
				}
				else if(t==b[7]){
					if(n==b[6]||n==b[8]||n==b[4]){
						exchange(t);
					}
				}
				else if(t==b[8]){
					if(n==b[5]||n==b[7]){
						exchange(t);
					}
				}
				if(b[0].getText().toString().equals("1")
						&&b[1].getText().toString().equals("2")
						&&b[2].getText().toString().equals("3")
						&&b[3].getText().toString().equals("4")
					    &&b[4].getText().toString().equals("5")
						&&b[5].getText().toString().equals("6")
						&&b[6].getText().toString().equals("7")
						&&b[7].getText().toString().equals("8")){
					Toast.makeText(MainActivity.this,"���ƴͼ�����ķ�����"+count+"!",Toast.LENGTH_SHORT).show();
				}
				
			}
        };
        o3=new OnClickListener(){

			@Override
			public void onClick(View v) {
				finish();
			}
        };
        close.setOnClickListener(o3);
        start.setOnClickListener(o1);
        for (int i = 0; i < 9; i++) {
			b[i].setOnClickListener(o2);
		}
        
   }

    protected void exchange(Button t) {
		n.setText(t.getText());
		t.setText("");
		n=t;
		count++;
		show.setText(count+"");
	}


	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
}
